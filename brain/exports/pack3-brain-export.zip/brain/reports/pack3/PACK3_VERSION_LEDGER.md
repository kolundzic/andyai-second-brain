# PACK3 Version Ledger

- v4.1.0 — Pack3 Operations TOC
- v4.2.0 — Inbox Intake Operation
- v4.3.0 — Routing Rules Operation
- v4.4.0 — Context Router v1
- v4.5.0 — Search Index Operation
- v4.6.0 — Memory Search CLI
- v4.7.0 — Project Snapshot Operation
- v4.8.0 — Repo Snapshot Operation
- v4.9.0 — Evidence Card Operation
- v5.0.0 — Decision Card Operation
- v5.1.0 — Approval Queue Operation
- v5.2.0 — Memory Lifecycle Operation
- v5.3.0 — Canon Signal Operation
- v5.4.0 — Client Brief Operation
- v5.5.0 — Meeting Debrief Operation
- v5.6.0 — Report Card Operation
- v5.7.0 — Ops Dashboard Operation
