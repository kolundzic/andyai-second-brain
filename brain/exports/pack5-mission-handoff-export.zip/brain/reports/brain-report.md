# Brain Report

Created: 2026-05-16T14:37:51Z

## Counts
{
  "projects": 3,
  "areas": 1,
  "resources": 2,
  "archives": 1,
  "evidence": 3,
  "decisions": 3,
  "skills": 1,
  "reports": 33,
  "inbox": 1,
  "approvals": 1
}

## Latest Tag
v6.0.0
